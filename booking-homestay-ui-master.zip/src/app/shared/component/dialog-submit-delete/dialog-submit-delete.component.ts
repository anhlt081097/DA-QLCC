import { Component } from '@angular/core';

@Component({
  selector: 'ngx-dialog-delete-submit',
  templateUrl: './dialog-submit-delete.component.html',
  styleUrls: ['./dialog-submit-delete.component.scss']
})
export class DialogDeleteSubmitComponent {

  constructor() { }

}
