import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-dialog-submit-refund',
  templateUrl: './dialog-submit-refund.component.html',
  styleUrls: ['./dialog-submit-refund.component.scss']
})
export class DialogSubmitRefundComponent {

  constructor() { }

}
