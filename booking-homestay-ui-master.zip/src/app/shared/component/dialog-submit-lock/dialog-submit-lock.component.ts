import { Component } from '@angular/core';

@Component({
  selector: 'ngx-dialog-submit-lock',
  templateUrl: './dialog-submit-lock.component.html',
  styleUrls: ['./dialog-submit-lock.component.scss']
})
export class DialogSubmitLockComponent{

  constructor() { }


}
