import { Component } from '@angular/core';

@Component({
  selector: 'ngx-dialog-delete-submit',
  templateUrl: './dialog-feedback.component.html',
  styleUrls: ['./dialog-feedback.component.scss']
})
export class DialogFeedBackComponent {

  constructor() { }

}
