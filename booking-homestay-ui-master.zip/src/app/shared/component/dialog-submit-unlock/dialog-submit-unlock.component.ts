import { Component } from '@angular/core';

@Component({
  selector: 'ngx-dialog-submit-unlock',
  templateUrl: './dialog-submit-unlock.component.html',
  styleUrls: ['./dialog-submit-unlock.component.scss']
})
export class DialogSubmitUnlockComponent {

  constructor() { }

}
