import { Component } from '@angular/core';

@Component({
  selector: 'ngx-dialog-delete-submit',
  templateUrl: './dialog-submit-booking.component.html',
  styleUrls: ['./dialog-submit-booking.component.scss']
})
export class DialogSubmitBookingComponent {

  constructor() { }

}
