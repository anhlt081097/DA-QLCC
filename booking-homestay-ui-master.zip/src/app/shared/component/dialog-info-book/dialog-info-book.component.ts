import { Component } from '@angular/core';

@Component({
  selector: 'ngx-dialog-delete-submit',
  templateUrl: './dialog-info-book.component.html',
  styleUrls: ['./dialog-info-book.component.scss']
})
export class DialogInfoBookComponent {

  constructor() { }

}
