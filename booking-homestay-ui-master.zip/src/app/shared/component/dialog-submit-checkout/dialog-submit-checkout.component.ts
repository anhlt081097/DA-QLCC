import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-dialog-submit-checkout',
  templateUrl: './dialog-submit-checkout.component.html',
  styleUrls: ['./dialog-submit-checkout.component.scss']
})
export class DialogSubmitCheckoutComponent {

  constructor() { }

}
