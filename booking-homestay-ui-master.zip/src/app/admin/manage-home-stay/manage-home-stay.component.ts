import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-home-stay',
  template: `<router-outlet></router-outlet>`,
})
export class ManageHomeStayComponent {
}
