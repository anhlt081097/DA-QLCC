import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-post',
  template: `<router-outlet></router-outlet>`,
})
export class ManagePostComponent {
}
