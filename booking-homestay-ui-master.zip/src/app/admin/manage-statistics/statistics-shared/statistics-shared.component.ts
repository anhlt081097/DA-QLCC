import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ngx-statistics-shared',
  templateUrl: './statistics-shared.component.html',
  styleUrls: ['./statistics-shared.component.scss']
})
export class StatisticsSharedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
