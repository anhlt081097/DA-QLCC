import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-untility',
  template: `<router-outlet></router-outlet>`,
})
export class ManageUntilityComponent {
}
