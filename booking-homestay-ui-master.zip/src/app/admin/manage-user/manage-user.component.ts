import { Component } from '@angular/core';

@Component({
  selector: 'app-manage-user',
  template: `<router-outlet></router-outlet>`,
})
export class ManageUserComponent {
}
